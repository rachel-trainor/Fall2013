package main

import (
	"aes"
)

func main() {
	aes.Printer()
}
